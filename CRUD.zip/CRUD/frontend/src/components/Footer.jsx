import React from 'react'

const Footer = () => {
  return (
    <div className="d-flex justify-content-center align-item-center p-2 text-white bg-dark" style={{borderTop:"1px solid pink"}}>Developed By Abhishek Rana</div>
  )
}

export default Footer