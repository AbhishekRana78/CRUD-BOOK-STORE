import React from 'react'

const BooksSection = ({data}) => {


    console.log(data);
  return (
    <div className="d-flex justify-content-around align-items-center  flex-wrap my-3" >
     {data && data.map((item,index)=>
     <div className="m-2" style={{width:"200px",height:"350px",border:"1px solid white"}}>
        <div>
            <img  style={{width:"200px", height:"210px"}} className="img-fluid"  src={item.image} alt="/" />
            </div>
      <h6  style ={{fontSize:"15px"}}className="text-black px-2 m-0 text-white"> {item.bookName.slice(0,50)}</h6>

      <b  style={{fontSize:"25px",color:"red"}}className="m-0 px-2">Rs. {item.price}  </b>

       <div className="d-flex justify-content-around align-item-center">
      <button className="btn btn-primary" >Update</button>
      <button className="btn btn-danger">Delete</button>
      </div>
    </div>)}


    </div>
  );
};

export default BooksSection