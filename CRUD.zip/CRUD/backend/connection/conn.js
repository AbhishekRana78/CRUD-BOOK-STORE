const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://abhi:abhi1234@cluster0.bgbievm.mongodb.net/crudop?retryWrites=true&w=majority&appName=Cluster0"
).then((res)=>console.log("connected"));