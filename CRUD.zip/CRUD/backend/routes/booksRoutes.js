const router= require("express").Router();

const bookModel = require("../models/booksModel");


//post
router.post("/add", async (req,res)=>{

    try {

        const newBook = new bookModel(req.body);
        await newBook.save().then(()=>{
            res.status(200).json({message:"book added"});
        })
    } catch (error) {

        console.log(error);
        
    }

});
//get req

router.get("/getBooks", async (req,res)=>{
    let books;

    try {
        books=await bookModel.find();
        res.status(200).json({books});
        
    } catch (error) {
        console.log(error);
        
    }

})
//get req by id

router.get("/getBooks/:id", async (req,res)=>{
    let book;
    const id= req.params.id;
    try {
        book=await bookModel.findById(id);
        res.status(200).json({book});

        
    } catch (error) {
        console.log(error)
        
    }
})

//update book by id
router.put("/updateBook/:id",async (req,res)=>{
    const{bookName,description,author,image,price} =req.body;
    const id= req.params.id;
    let book;
    try {
        book=await bookModel.findByIdAndUpdate(id,{bookName,description,author,image,price});
        await book.save().then(()=>
            res.status(200).json(book))
        
    } catch (error) {
        console.log(error)
        
    }
})

//delete book by id
router.delete("/deleteBook/:id"  ,async(req,res)=>{
  const id=req.params.id;
  let book;
  try {
    book= await bookModel.findByIdAndDelete(id).then(()=>
    res.status(201).json({message: "deleted"}))
    
  } catch (error) {
    console.log(error)
    
  }
})
module.exports =router;